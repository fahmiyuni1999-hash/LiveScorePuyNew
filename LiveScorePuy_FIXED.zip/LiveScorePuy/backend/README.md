# LiveScore Puy Backend

Backend referensi: Sportmonks -> normalisasi -> filter tim favorit -> Firebase Cloud Messaging.

## Menjalankan
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

Set `SPORTMONKS_TOKEN` di `.env`.

FCM server membutuhkan Firebase Admin credentials melalui `GOOGLE_APPLICATION_CREDENTIALS`.
Tanpa credential FCM, API tetap bisa berjalan tetapi push tidak dikirim.

## Endpoint
- GET /health
- GET /v1/live
- GET /v1/fixtures?date=YYYY-MM-DD
- GET /v1/matches/{id}
- GET /v1/teams/search?q=persija
- GET /v1/competitions
- POST /v1/devices/register
- POST /v1/devices/{token}/teams/{team_id}
- DELETE /v1/devices/{token}/teams/{team_id}

Device registration:
```json
{"token":"FCM_DEVICE_TOKEN","team_ids":["123","456"]}
```

Server hanya mengirim event untuk pertandingan yang melibatkan team_id yang disubscribe.
