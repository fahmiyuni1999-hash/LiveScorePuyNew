# Backend contract

Android mengirim:
`POST /v1/devices/register`
```json
{"token":"FCM_TOKEN","team_ids":["123","456"]}
```

FCM data:
- match_id
- event_id
- event_type

Jenis event:
GOAL, VAR, YELLOW, RED, HALF_TIME, FULL_TIME, KICKOFF, POSTPONED.

Backend menjadi filter sehingga perangkat tidak menerima pertandingan tim lain.
