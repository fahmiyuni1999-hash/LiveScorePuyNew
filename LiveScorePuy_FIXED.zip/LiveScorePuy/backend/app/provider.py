import httpx

class Sportmonks:
    def __init__(self, base_url, token):
        self.base_url = base_url
        self.token = token

    async def get(self, path, params=None):
        if not self.token:
            raise RuntimeError("SPORTMONKS_TOKEN belum dikonfigurasi")
        params = dict(params or {})
        params["api_token"] = self.token
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(
                f"{self.base_url}/{path.lstrip('/')}",
                params=params
            )
            r.raise_for_status()
            return r.json()

    async def inplay(self):
        return await self.get(
            "/livescores/inplay",
            {"include": "participants;scores;periods;events;state;league"}
        )

    async def fixtures_by_date(self, date):
        return await self.get(
            f"/fixtures/date/{date}",
            {"include": "participants;scores;periods;events;state;league"}
        )

    async def fixture(self, fixture_id):
        return await self.get(
            f"/fixtures/{fixture_id}",
            {"include": "participants;scores;periods;events;state;league;lineups;statistics"}
        )

    async def leagues(self):
        return await self.get("/leagues")

    async def search_teams(self, query):
        return await self.get(f"/teams/search/{query}", {"include": "country"})

def first(items, predicate=lambda x: True):
    for x in items or []:
        if predicate(x):
            return x
    return None

def normalize_fixture(f):
    participants = f.get("participants") or []
    home = first(participants, lambda p: p.get("meta", {}).get("location") == "home")
    away = first(participants, lambda p: p.get("meta", {}).get("location") == "away")
    if not home and participants:
        home = participants[0]
    if not away and len(participants) > 1:
        away = participants[1]
    home = home or {}
    away = away or {}

    def score_for(pid):
        for s in f.get("scores") or []:
            if s.get("participant_id") == pid:
                return (s.get("score") or {}).get("goals", 0)
        return 0

    state = f.get("state") or {}
    league = f.get("league") or {}

    return {
        "id": str(f.get("id")),
        "provider": "sportmonks",
        "name": f.get("name"),
        "starting_at": f.get("starting_at"),
        "status": state.get("short_name") or state.get("name") or "UNKNOWN",
        "state": state,
        "league": {"id": league.get("id"), "name": league.get("name") or "Unknown"},
        "home": {"id": str(home.get("id")), "name": home.get("name"), "logo": home.get("image_path")},
        "away": {"id": str(away.get("id")), "name": away.get("name"), "logo": away.get("image_path")},
        "home_score": score_for(home.get("id")),
        "away_score": score_for(away.get("id")),
        "events": f.get("events") or [],
        "updated_at": f.get("updated_at")
    }

def event_key(match, event):
    raw = (
        event.get("id")
        or f"{match['id']}:{event.get('minute')}:{event.get('type_id')}:"
           f"{event.get('player_id')}:{event.get('result')}"
    )
    return f"sm:{raw}"

def event_kind(event):
    t = str(
        (event.get("type") or {}).get("name")
        or event.get("type_name")
        or ""
    ).lower()
    if "goal" in t:
        return "GOAL"
    if "yellow" in t:
        return "YELLOW"
    if "red" in t:
        return "RED"
    if "var" in t:
        return "VAR"
    if "half" in t:
        return "HALF_TIME"
    if "full" in t or "ended" in t:
        return "FULL_TIME"
    if "kick" in t or "start" in t:
        return "KICKOFF"
    return None
