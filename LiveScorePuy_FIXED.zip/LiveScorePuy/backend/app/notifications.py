import firebase_admin
from firebase_admin import messaging

class Notifier:
    def __init__(self):
        self.enabled = False
        try:
            if not firebase_admin._apps:
                firebase_admin.initialize_app()
            self.enabled = True
        except Exception:
            self.enabled = False

    def send(self, token, title, body, data):
        if not self.enabled:
            return {"sent": False, "reason": "FCM belum dikonfigurasi"}
        message = messaging.Message(
            token=token,
            notification=messaging.Notification(title=title, body=body),
            data={k: str(v) for k, v in data.items()},
            android=messaging.AndroidConfig(
                priority="high",
                notification=messaging.AndroidNotification(
                    channel_id="match_events",
                    sound="default"
                )
            )
        )
        try:
            return {"sent": True, "id": messaging.send(message)}
        except Exception as e:
            return {"sent": False, "reason": str(e)}

def title_for(kind):
    return {
        "GOAL": "⚽ GOL!",
        "VAR": "VAR / Gol Ditinjau",
        "YELLOW": "🟨 Kartu Kuning",
        "RED": "🟥 Kartu Merah",
        "HALF_TIME": "⏸ Babak Pertama Selesai",
        "FULL_TIME": "🏁 Pertandingan Selesai",
        "KICKOFF": "▶️ Kick-off",
        "POSTPONED": "⏸ Pertandingan Ditunda",
    }.get(kind, "LiveScore Puy")

def body_for(match, kind, event):
    score = f"{match['home_score']} - {match['away_score']}"
    body = f"{match['home']['name']} {score} {match['away']['name']} • {kind.replace('_',' ').title()}"
    if event.get("minute") is not None:
        body += f" • {event['minute']}'"
    return body
