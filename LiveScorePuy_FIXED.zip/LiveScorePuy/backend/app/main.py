import asyncio
from datetime import datetime, timezone
from contextlib import asynccontextmanager
from fastapi import FastAPI, Query
from pydantic import BaseModel, Field

from .config import settings
from .store import Store
from .provider import Sportmonks, normalize_fixture, event_key, event_kind
from .notifications import Notifier, title_for, body_for

store = Store(settings.db_path)
provider = Sportmonks(settings.sportmonks_base_url, settings.sportmonks_token)
notifier = Notifier()

class DeviceRegistration(BaseModel):
    token: str = Field(min_length=10)
    team_ids: list[str] = []

async def process_payload(payload):
    now = datetime.now(timezone.utc).isoformat()
    for raw in payload.get("data") or []:
        match = normalize_fixture(raw)
        team_ids = [match["home"]["id"], match["away"]["id"]]
        for event in match.get("events") or []:
            kind = event_kind(event)
            if not kind:
                continue
            eid = event_key(match, event)
            for token in store.tokens_for_teams(team_ids):
                if store.already_delivered(token, eid):
                    continue
                result = notifier.send(
                    token,
                    title_for(kind),
                    body_for(match, kind, event),
                    {
                        "match_id": match["id"],
                        "event_id": eid,
                        "event_type": kind
                    }
                )
                if result.get("sent") or result.get("reason") == "FCM belum dikonfigurasi":
                    store.mark_delivered(token, eid, now)

async def poll_loop():
    while True:
        try:
            await process_payload(await provider.inplay())
        except Exception as e:
            print(f"[poll] {type(e).__name__}: {e}")
        await asyncio.sleep(settings.poll_seconds)

@asynccontextmanager
async def lifespan(app):
    task = asyncio.create_task(poll_loop())
    yield
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass

app = FastAPI(title="LiveScore Puy API", version="1.0.0", lifespan=lifespan)

@app.get("/health")
async def health():
    return {"ok": True, "poll_seconds": settings.poll_seconds, "fcm_enabled": notifier.enabled}

@app.get("/v1/live")
async def live():
    return await provider.inplay()

@app.get("/v1/fixtures")
async def fixtures(date: str = Query(..., pattern=r"^\d{4}-\d{2}-\d{2}$")):
    return await provider.fixtures_by_date(date)

@app.get("/v1/matches/{fixture_id}")
async def match(fixture_id: str):
    return await provider.fixture(fixture_id)

@app.get("/v1/teams/search")
async def teams(q: str = Query(..., min_length=2)):
    return await provider.search_teams(q)

@app.get("/v1/competitions")
async def competitions():
    return await provider.leagues()

@app.post("/v1/devices/register")
async def register(device: DeviceRegistration):
    store.register_device(
        device.token,
        device.team_ids,
        datetime.now(timezone.utc).isoformat()
    )
    return {"ok": True, "team_ids": sorted(set(device.team_ids))}

@app.post("/v1/devices/{token}/teams/{team_id}")
async def add_team(token: str, team_id: str):
    store.add_team(token, team_id, datetime.now(timezone.utc).isoformat())
    return {"ok": True}

@app.delete("/v1/devices/{token}/teams/{team_id}")
async def remove_team(token: str, team_id: str):
    store.remove_team(token, team_id)
    return {"ok": True}

@app.post("/v1/admin/test-notification")
async def test_notification(token: str):
    return notifier.send(
        token,
        "LiveScore Puy",
        "Notifikasi tes berhasil.",
        {"event_type": "TEST"}
    )
