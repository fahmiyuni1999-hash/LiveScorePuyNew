import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    sportmonks_token: str = os.getenv("SPORTMONKS_TOKEN", "")
    sportmonks_base_url: str = os.getenv(
        "SPORTMONKS_BASE_URL",
        "https://api.sportmonks.com/v3/football"
    ).rstrip("/")
    poll_seconds: int = max(5, int(os.getenv("POLL_SECONDS", "5")))
    port: int = int(os.getenv("PORT", "8080"))
    db_path: str = os.getenv("DB_PATH", "./livescorepuy.db")

settings = Settings()
