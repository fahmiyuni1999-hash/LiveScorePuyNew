import sqlite3
from threading import Lock

class Store:
    def __init__(self, path: str):
        self.path = path
        self.lock = Lock()
        self.init()

    def conn(self):
        c = sqlite3.connect(self.path, check_same_thread=False)
        c.row_factory = sqlite3.Row
        return c

    def init(self):
        with self.lock, self.conn() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS devices (
              token TEXT PRIMARY KEY,
              updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS subscriptions (
              token TEXT NOT NULL,
              team_id TEXT NOT NULL,
              PRIMARY KEY(token, team_id)
            );
            CREATE TABLE IF NOT EXISTS delivered_events (
              token TEXT NOT NULL,
              event_id TEXT NOT NULL,
              created_at TEXT NOT NULL,
              PRIMARY KEY(token, event_id)
            );
            """)

    def register_device(self, token, team_ids, now):
        with self.lock, self.conn() as c:
            c.execute(
                "INSERT INTO devices(token,updated_at) VALUES(?,?) "
                "ON CONFLICT(token) DO UPDATE SET updated_at=excluded.updated_at",
                (token, now)
            )
            c.execute("DELETE FROM subscriptions WHERE token=?", (token,))
            c.executemany(
                "INSERT OR IGNORE INTO subscriptions(token,team_id) VALUES(?,?)",
                [(token, t) for t in set(team_ids)]
            )

    def add_team(self, token, team_id, now):
        with self.lock, self.conn() as c:
            c.execute(
                "INSERT INTO devices(token,updated_at) VALUES(?,?) "
                "ON CONFLICT(token) DO UPDATE SET updated_at=excluded.updated_at",
                (token, now)
            )
            c.execute(
                "INSERT OR IGNORE INTO subscriptions(token,team_id) VALUES(?,?)",
                (token, team_id)
            )

    def remove_team(self, token, team_id):
        with self.lock, self.conn() as c:
            c.execute(
                "DELETE FROM subscriptions WHERE token=? AND team_id=?",
                (token, team_id)
            )

    def tokens_for_teams(self, team_ids):
        ids = list(set(team_ids))
        if not ids:
            return []
        q = ",".join("?" for _ in ids)
        with self.lock, self.conn() as c:
            rows = c.execute(
                f"SELECT DISTINCT token FROM subscriptions WHERE team_id IN ({q})",
                ids
            ).fetchall()
            return [r["token"] for r in rows]

    def already_delivered(self, token, event_id):
        with self.lock, self.conn() as c:
            return c.execute(
                "SELECT 1 FROM delivered_events WHERE token=? AND event_id=?",
                (token, event_id)
            ).fetchone() is not None

    def mark_delivered(self, token, event_id, now):
        with self.lock, self.conn() as c:
            c.execute(
                "INSERT OR IGNORE INTO delivered_events(token,event_id,created_at) VALUES(?,?,?)",
                (token, event_id, now)
            )
