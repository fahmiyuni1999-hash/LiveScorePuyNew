# LiveScore Puy — Status Penyelesaian

Sudah ditambahkan:
- backend FastAPI + Sportmonks
- polling in-play 5 detik
- normalisasi fixture/event
- SQLite subscription device/team
- deduplikasi event
- Firebase Admin FCM sender
- Android FCM service + notification channel
- backend API client scaffold
- kontrak API dan Dockerfile
- filter notifikasi berbasis tim favorit

Masih membutuhkan credential eksternal:
1. Sportmonks API token
2. Firebase project + google-services.json
3. Firebase Admin service-account
4. URL HTTPS backend production

Jangan masukkan Sportmonks token atau Firebase service account ke APK/Git.
