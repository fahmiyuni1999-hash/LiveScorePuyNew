# LiveScore Puy

Project Android Studio untuk prototype aplikasi LiveScore Puy.

## Status
- Kotlin + Jetpack Compose + Material 3
- Android 8.0+ (minSdk 26)
- Home / Live / Jadwal / Favorit / Kompetisi
- Detail pertandingan
- Pemilihan tim favorit
- Mode fokus notifikasi tim favorit
- Status LIVE / UPCOMING / FINISHED / POSTPONED
- Mock repository agar UI bisa berjalan tanpa API
- Logo aplikasi merah/biru/putih/hitam

## Membuka
Buka folder ini dengan Android Studio versi modern. Android Studio akan memakai Gradle/SDK lokal yang terpasang.

## Data real-time
Saat ini data adalah MOCK. Untuk produksi, sambungkan `MockRepository` ke provider sepak bola berlisensi melalui Retrofit/WebSocket/push. Jangan memasukkan API key ke source control.

## FCM
Firebase Cloud Messaging belum diaktifkan karena membutuhkan project Firebase milik pengguna dan `google-services.json`. Struktur aplikasi sengaja dibuat agar FCM dapat ditambahkan pada tahap integrasi backend.

## Catatan
Prototype ini belum dapat menjamin latency nol; latency skor bergantung pada provider, jaringan, dan mekanisme update.

## Integrasi real-time
Lihat `REAL_DATA_INTEGRATION.md` untuk provider dan langkah menghubungkan feed nyata.
