package com.livescorepuy.app.data

import com.livescorepuy.app.model.SportmonksResponse
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface SportmonksApi {
    @GET("livescores/inplay")
    suspend fun inPlay(
        @Query("include") include: String = "participants;scores;state;events.type"
    ): SportmonksResponse

    @GET("livescores/latest")
    suspend fun latestUpdated(
        @Query("include") include: String = "participants;scores;state;events.type"
    ): SportmonksResponse

    @GET("fixtures/date/{date}")
    suspend fun fixturesByDate(
        @Path("date") date: String,
        @Query("include") include: String = "participants;scores;state;events.type"
    ): SportmonksResponse

    @GET("fixtures/{id}")
    suspend fun fixture(
        @Path("id") id: Long,
        @Query("include") include: String = "participants;scores;state;events.type;lineups.player;statistics"
    ): SportmonksResponse
}
