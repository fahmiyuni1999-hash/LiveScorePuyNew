package com.livescorepuy.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class FavoritesStore(context: Context) {
    private val prefs = context.getSharedPreferences("favorites", Context.MODE_PRIVATE)
    private val _ids = MutableStateFlow(prefs.getStringSet("team_ids", emptySet()) ?: emptySet())
    val teamIds: StateFlow<Set<String>> = _ids

    fun toggle(id: String) {
        val next = _ids.value.toMutableSet()
        if (!next.add(id)) next.remove(id)
        _ids.value = next
        prefs.edit().putStringSet("team_ids", next).apply()
    }

    fun isFavorite(id: String) = id in _ids.value
}
