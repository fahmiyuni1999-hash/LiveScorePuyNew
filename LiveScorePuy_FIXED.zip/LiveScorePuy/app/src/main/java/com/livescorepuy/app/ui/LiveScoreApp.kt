package com.livescorepuy.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.livescorepuy.app.data.FavoritesStore
import com.livescorepuy.app.data.MockRepository
import com.livescorepuy.app.model.*

private val Bg = Color(0xFF05070B)
private val Card = Color(0xFF0D1420)
private val Muted = Color(0xFF8E9AAA)
private val Red = Color(0xFFFF1738)
private val Blue = Color(0xFF087CFF)

@Composable
fun LiveScoreApp(repo: MockRepository, favorites: FavoritesStore) {
    var tab by remember { mutableStateOf(0) }
    var detail by remember { mutableStateOf<Match?>(null) }
    var settings by remember { mutableStateOf(false) }
    var notif by remember { mutableStateOf(false) }
    val matches by repo.matches.collectAsState()
    val favIds by favorites.teamIds.collectAsState()

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(15000)
            repo.refreshLive()
        }
    }

    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column {
            TopBar(onSettings = { settings = true })
            Box(Modifier.weight(1f)) {
                when {
                    notif -> NotificationScreen(onBack = { notif = false })
                    settings -> SettingsScreen(
                        onBack = { settings = false },
                        onNotifications = { notif = true }
                    )
                    detail != null -> MatchDetail(detail!!, onBack = { detail = null })
                    else -> when (tab) {
                        0 -> HomeScreen(matches, favIds, { detail = it }, favorites)
                        1 -> LiveScreen(matches, { detail = it })
                        2 -> ScheduleScreen(matches, { detail = it })
                        3 -> FavoritesScreen(repo.teams(), matches, favIds, favorites, { detail = it })
                        else -> CompetitionsScreen(matches)
                    }
                }
            }
            if (!settings && !notif && detail == null) BottomNav(tab) { tab = it }
        }
    }
}

@Composable private fun TopBar(onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Live", fontWeight = FontWeight.Black, color = Color.White, style = MaterialTheme.typography.titleLarge)
        Text("Score", fontWeight = FontWeight.Black, color = Red, style = MaterialTheme.typography.titleLarge)
        Text(" PUY", fontWeight = FontWeight.Black, color = Color.White)
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Pengaturan") }
    }
}

@Composable private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xFF080D14)) {
        listOf(
            Icons.Default.Home to "Beranda",
            Icons.Default.SportsSoccer to "Live",
            Icons.Default.CalendarMonth to "Jadwal",
            Icons.Default.Star to "Favorit",
            Icons.Default.EmojiEvents to "Kompetisi"
        ).forEachIndexed { i, pair ->
            NavigationBarItem(selected = selected == i, onClick = { onSelect(i) },
                icon = { Icon(pair.first, null) }, label = { Text(pair.second) })
        }
    }
}

@Composable private fun HomeScreen(matches: List<Match>, favIds: Set<String>, onDetail: (Match) -> Unit, fav: FavoritesStore) {
    LazyColumn(Modifier.padding(horizontal = 14.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item { Text("Beranda", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Spacer(Modifier.height(10.dp)); PromoCard() }
        item { SectionTitle("Pertandingan Favorit", "Hanya tim saya") }
        val favoriteMatches = matches.filter { it.home.id in favIds || it.away.id in favIds }
        items(if (favoriteMatches.isEmpty()) matches.take(2) else favoriteMatches) { MatchCard(it, onDetail) }
        item { SectionTitle("Live Sekarang", "Diperbarui otomatis") }
        items(matches.filter { it.status == MatchStatus.LIVE }) { MatchCard(it, onDetail) }
    }
}

@Composable private fun PromoCard() {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111C2B)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("⚽ LiveScore Puy", fontWeight = FontWeight.Bold)
            Text("Fokus ke tim favorit, tanpa notifikasi pertandingan yang tidak kamu perlukan.", color = Muted, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Text("Real-time • Favorit • Jadwal • Notifikasi", color = Color.White, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable private fun SectionTitle(title: String, sub: String) {
    Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(7.dp))
        Text("• $sub", color = Muted, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable private fun MatchCard(match: Match, onDetail: (Match) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Card),
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onDetail(match) }
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(match.competition, color = Muted, style = MaterialTheme.typography.labelSmall)
                when (match.status) {
                    MatchStatus.LIVE -> Text("LIVE ${match.minute}'", color = Color.White, modifier = Modifier.background(Red, MaterialTheme.shapes.small).padding(horizontal = 7.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall)
                    MatchStatus.POSTPONED -> Text("DITUNDA", color = Color(0xFFFFB6BF), style = MaterialTheme.typography.labelSmall)
                    else -> Text(match.kickoff, color = Muted, style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TeamName(match.home.name)
                Text("${match.homeScore} – ${match.awayScore}", modifier = Modifier.width(90.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                TeamName(match.away.name)
            }
            if (match.status == MatchStatus.POSTPONED) Text(match.postponedReason ?: "Pertandingan ditunda", color = Color(0xFFFFB6BF), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable private fun TeamName(name: String) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(34.dp).background(Color(0xFF182638), MaterialTheme.shapes.medium), contentAlignment = Alignment.Center) { Text("⚽") }
        Spacer(Modifier.height(4.dp))
        Text(name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable private fun LiveScreen(matches: List<Match>, onDetail: (Match) -> Unit) {
    LazyColumn(Modifier.padding(horizontal = 14.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item { Text("Live Score", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); FilterChips() }
        items(matches.filter { it.status == MatchStatus.LIVE }) { MatchCard(it, onDetail) }
    }
}

@Composable private fun FilterChips() {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        listOf("Semua","Liga 1","Liga 2","Eropa").forEachIndexed { i, s ->
            Surface(color = if (i == 0) Red else Color(0xFF0A1018), shape = MaterialTheme.shapes.small) {
                Text(s, Modifier.padding(horizontal = 11.dp, vertical = 8.dp), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable private fun ScheduleScreen(matches: List<Match>, onDetail: (Match) -> Unit) {
    LazyColumn(Modifier.padding(horizontal = 14.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item { Text("Jadwal", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); FilterChips() }
        items(matches.filter { it.status == MatchStatus.UPCOMING || it.status == MatchStatus.POSTPONED }) { MatchCard(it, onDetail) }
    }
}

@Composable private fun FavoritesScreen(teams: List<Team>, matches: List<Match>, favIds: Set<String>, store: FavoritesStore, onDetail: (Match) -> Unit) {
    LazyColumn(Modifier.padding(horizontal = 14.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item { Text("Tim Favorit", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("Pilih tim yang ingin kamu ikuti. Notifikasi bisa difokuskan hanya ke tim ini.", color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp)) }
        items(teams) { team ->
            Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("⚽", modifier = Modifier.size(40.dp), style = MaterialTheme.typography.titleLarge)
                    Column(Modifier.weight(1f)) { Text(team.name, fontWeight = FontWeight.Bold); Text(team.competition, color = Muted, style = MaterialTheme.typography.labelSmall) }
                    Switch(checked = team.id in favIds, onCheckedChange = { store.toggle(team.id) })
                }
            }
        }
        item {
            val fm = matches.filter { it.home.id in favIds || it.away.id in favIds }
            SectionTitle("Pertandingan Tim Saya", "${fm.size} pertandingan")
        }
        items(matches.filter { it.home.id in favIds || it.away.id in favIds }) { MatchCard(it, onDetail) }
    }
}

@Composable private fun CompetitionsScreen(matches: List<Match>) {
    val comps = matches.map { it.competition }.distinct()
    LazyColumn(Modifier.padding(horizontal = 14.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item { Text("Kompetisi", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        items(comps) { c ->
            Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🏆", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.width(12.dp))
                    Column { Text(c, fontWeight = FontWeight.Bold); Text("Jadwal • Hasil • Klasemen", color = Muted, style = MaterialTheme.typography.labelSmall) }
                }
            }
        }
    }
}

@Composable private fun MatchDetail(match: Match, onBack: () -> Unit) {
    LazyColumn(Modifier.padding(horizontal = 14.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Kembali") }
                Text("Detail Pertandingan", fontWeight = FontWeight.Bold)
            }
            Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(match.competition, color = Muted, style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        TeamName(match.home.name)
                        Column(Modifier.width(100.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (match.status == MatchStatus.LIVE) "${match.homeScore}–${match.awayScore}" else "VS", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black)
                            Text(if (match.status == MatchStatus.LIVE) "LIVE ${match.minute}'" else match.kickoff, color = if (match.status == MatchStatus.LIVE) Red else Muted)
                        }
                        TeamName(match.away.name)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        item { Text("Event Pertandingan", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp)) }
        items(match.events) { e ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(eventIcon(e.type), modifier = Modifier.width(35.dp))
                Column { Text(e.text, fontWeight = FontWeight.SemiBold); Text("${e.team} • ${e.minute}'", color = Muted, style = MaterialTheme.typography.labelSmall) }
            }
        }
        if (match.status == MatchStatus.POSTPONED) {
            item {
                Spacer(Modifier.height(8.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF271117))) {
                    Column(Modifier.padding(14.dp)) {
                        Text("⏸ Pertandingan Ditunda", color = Color(0xFFFFB6BF), fontWeight = FontWeight.Bold)
                        Text(match.postponedReason ?: "", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Text(match.rescheduledTo ?: "", color = Color.White, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

private fun eventIcon(type: MatchEventType) = when (type) {
    MatchEventType.GOAL -> "⚽"; MatchEventType.VAR -> "🔵"; MatchEventType.YELLOW -> "🟨"; MatchEventType.RED -> "🟥"
    MatchEventType.HALF_TIME -> "⏱"; MatchEventType.FULL_TIME -> "🏁"; MatchEventType.KICKOFF -> "🟢"; MatchEventType.POSTPONED -> "⏸"
}

@Composable private fun SettingsScreen(onBack: () -> Unit, onNotifications: () -> Unit) {
    Column(Modifier.padding(horizontal = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Kembali") }; Text("Pengaturan", fontWeight = FontWeight.Bold) }
        SettingRow("⭐ Tim Favorit", "Kelola tim yang kamu ikuti")
        SettingRow("🔔 Notifikasi", "Fokus notifikasi hanya tim favorit", onClick = onNotifications)
        SettingRow("🌙 Tampilan", "Mode gelap")
        SettingRow("🌐 Bahasa", "Indonesia")
        SettingRow("ℹ️ Tentang", "LiveScore Puy 1.0.0")
    }
}

@Composable private fun SettingRow(title: String, sub: String, onClick: (() -> Unit)? = null) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable(enabled = onClick != null) { onClick?.invoke() }) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(sub, color = Muted, style = MaterialTheme.typography.labelSmall) }
            if (onClick != null) Icon(Icons.Default.ChevronRight, null)
        }
    }
}

@Composable private fun NotificationScreen(onBack: () -> Unit) {
    Column(Modifier.padding(horizontal = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Kembali") }; Text("Notifikasi & Suara", fontWeight = FontWeight.Bold) }
        Text("Untuk tim favorit", color = Muted, style = MaterialTheme.typography.bodySmall)
        listOf("⚽ Gol","🔵 Gol dianulir / VAR","🟨 Kartu kuning","🟥 Kartu merah","🏁 Kickoff / HT / FT","⏸ Ditunda / Rescheduled").forEach {
            Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(it, Modifier.weight(1f)); Switch(true, {})
                }
            }
        }
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Simpan") }
    }
}
