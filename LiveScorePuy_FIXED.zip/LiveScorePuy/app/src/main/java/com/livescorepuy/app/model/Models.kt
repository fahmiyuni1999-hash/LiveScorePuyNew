package com.livescorepuy.app.model

enum class MatchStatus { UPCOMING, LIVE, FINISHED, POSTPONED }

enum class MatchEventType { GOAL, VAR, YELLOW, RED, HALF_TIME, FULL_TIME, KICKOFF, POSTPONED }

data class Team(
    val id: String,
    val name: String,
    val shortName: String,
    val competition: String
)

data class MatchEvent(
    val minute: Int,
    val type: MatchEventType,
    val team: String,
    val text: String
)

data class Match(
    val id: String,
    val competition: String,
    val home: Team,
    val away: Team,
    val kickoff: String,
    val status: MatchStatus,
    val homeScore: Int = 0,
    val awayScore: Int = 0,
    val minute: Int? = null,
    val events: List<MatchEvent> = emptyList(),
    val postponedReason: String? = null,
    val rescheduledTo: String? = null
)
