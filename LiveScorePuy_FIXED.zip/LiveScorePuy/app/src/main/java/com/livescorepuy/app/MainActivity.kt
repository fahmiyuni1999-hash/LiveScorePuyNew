package com.livescorepuy.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessaging
import com.livescorepuy.app.data.BackendClient
import com.livescorepuy.app.data.DeviceRegistration
import com.livescorepuy.app.data.FavoritesStore
import com.livescorepuy.app.data.MockRepository
import com.livescorepuy.app.notifications.NotificationBootstrap
import com.livescorepuy.app.ui.LiveScoreApp
import com.livescorepuy.app.ui.LiveScorePuyTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

class MainActivity : ComponentActivity() {
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationBootstrap.createChannels(this)
        requestNotificationPermissionIfNeeded()

        val repo = MockRepository()
        val favorites = FavoritesStore(this)

        setContent {
            LiveScorePuyTheme {
                LiveScoreApp(repo, favorites)
            }
        }

        syncFcmAndFavorites(favorites)
    }

    private fun syncFcmAndFavorites(favorites: FavoritesStore) {
        if (BuildConfig.BACKEND_BASE_URL.contains("YOUR-BACKEND")) return

        runCatching {
            FirebaseMessaging.getInstance().token
                .addOnSuccessListener { token ->
                    ioScope.launch {
                        runCatching {
                            BackendClient.create(BuildConfig.BACKEND_BASE_URL)
                                .register(DeviceRegistration(token, favorites.teamIds.value.toList()))
                        }
                    }
                }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    override fun onDestroy() {
        ioScope.coroutineContext.cancel()
        super.onDestroy()
    }
}
