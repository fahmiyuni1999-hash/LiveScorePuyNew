package com.livescorepuy.app.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

object NotificationBootstrap {
    const val CHANNEL_ID = "match_events"

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Event pertandingan",
                    NotificationManager.IMPORTANCE_HIGH
                )
            )
        }
    }
}
