package com.livescorepuy.app.data

import com.livescorepuy.app.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MockRepository {
    private val persib = Team("persib","Persib Bandung","PERSIB","Liga 1 Indonesia")
    private val bali = Team("bali","Bali United","BALI","Liga 1 Indonesia")
    private val persija = Team("persija","Persija Jakarta","PERSIJA","Liga 1 Indonesia")
    private val psbs = Team("psbs","PSBS Biak","PSBS","Liga 1 Indonesia")
    private val real = Team("real","Real Madrid","RMA","La Liga")
    private val barca = Team("barca","Barcelona","BAR","La Liga")
    private val psm = Team("psm","PSM Makassar","PSM","Liga 1 Indonesia")
    private val dewa = Team("dewa","Dewa United","DEWA","Liga 1 Indonesia")
    private val barito = Team("barito","Barito Putera","BARITO","Liga 1 Indonesia")
    private val persita = Team("persita","Persita","PERSITA","Liga 1 Indonesia")

    private val _matches = MutableStateFlow(
        listOf(
            Match("m1","Liga 1 Indonesia",persija,psbs,"15:30",MatchStatus.LIVE,1,0,23,
                listOf(
                    MatchEvent(23,MatchEventType.GOAL,"Persija Jakarta","Gol!"),
                    MatchEvent(18,MatchEventType.YELLOW,"PSBS Biak","Kartu kuning")
                )),
            Match("m2","Liga 1 Indonesia",psm,dewa,"19:00",MatchStatus.LIVE,2,1,45),
            Match("m3","Liga 1 Indonesia",persib,bali,"20:30",MatchStatus.UPCOMING),
            Match("m4","La Liga",real,barca,"02:00","UPCOMING".let { MatchStatus.UPCOMING }),
            Match("m5","Liga 1 Indonesia",barito,persita,"19:00",MatchStatus.POSTPONED,
                postponedReason = "Pertandingan ditunda", rescheduledTo = "Jadwal baru akan diumumkan")
        )
    )
    val matches: StateFlow<List<Match>> = _matches.asStateFlow()

    fun refreshLive() {
        _matches.value = _matches.value.map {
            if (it.status == MatchStatus.LIVE && it.minute != null)
                it.copy(minute = (it.minute + 1).coerceAtMost(90))
            else it
        }
    }

    fun teams(): List<Team> = listOf(persib,bali,persija,psbs,real,barca,psm,dewa,barito,persita)
}
