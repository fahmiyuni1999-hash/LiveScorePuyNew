package com.livescorepuy.app.data

import com.livescorepuy.app.model.Match
import kotlinx.coroutines.flow.Flow

interface FootballProvider {
    fun liveMatches(): Flow<Result<List<Match>>>
    suspend fun fixtures(dateIso: String): Result<List<Match>>
    suspend fun fixture(id: Long): Result<Match?>
}
