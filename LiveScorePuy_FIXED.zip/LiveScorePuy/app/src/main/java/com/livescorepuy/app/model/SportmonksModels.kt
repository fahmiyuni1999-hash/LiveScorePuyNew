package com.livescorepuy.app.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class SportmonksResponse(
    val data: List<SportmonksFixture> = emptyList()
)

@Serializable
data class SportmonksFixture(
    val id: Long = 0,
    val name: String = "",
    val starting_at: String? = null,
    val participants: List<SportmonksParticipant> = emptyList(),
    val scores: List<SportmonksScore> = emptyList(),
    val state: SportmonksState? = null,
    val events: List<SportmonksEvent> = emptyList()
)

@Serializable
data class SportmonksParticipant(
    val id: Long = 0,
    val name: String = "",
    val meta: SportmonksMeta? = null
)

@Serializable
data class SportmonksMeta(
    val location: String? = null
)

@Serializable
data class SportmonksScore(
    val goals: Int? = null,
    val description: String? = null,
    val participant_id: Long? = null
)

@Serializable
data class SportmonksState(
    val name: String? = null,
    val short_name: String? = null
)

@Serializable
data class SportmonksEvent(
    val id: Long = 0,
    val minute: Int? = null,
    val type: SportmonksEventType? = null,
    val participant_id: Long? = null,
    val player_name: String? = null,
    val result: String? = null
)

@Serializable
data class SportmonksEventType(
    val name: String? = null,
    val code: String? = null
)
