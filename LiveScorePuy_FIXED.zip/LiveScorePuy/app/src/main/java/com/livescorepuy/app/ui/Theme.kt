package com.livescorepuy.app.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Red = Color(0xFFFF1738)
private val Blue = Color(0xFF087CFF)
private val Black = Color(0xFF05070B)
private val Card = Color(0xFF0D1420)

private val DarkColors = darkColorScheme(
    primary = Red,
    secondary = Blue,
    background = Black,
    surface = Card,
    onBackground = Color(0xFFF6F8FB),
    onSurface = Color(0xFFF6F8FB)
)

@Composable
fun LiveScorePuyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, typography = Typography(), content = content)
}
