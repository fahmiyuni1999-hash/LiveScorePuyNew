package com.livescorepuy.app.data

import android.content.Context

enum class NotificationMode { ALL_EVENTS, GOALS_AND_FINAL, OFF }

class NotificationPrefsStore(context: Context) {
    private val prefs = context.getSharedPreferences("notification_prefs", Context.MODE_PRIVATE)

    fun mode(teamId: String): NotificationMode =
        runCatching {
            NotificationMode.valueOf(
                prefs.getString("mode_$teamId", NotificationMode.ALL_EVENTS.name)!!
            )
        }.getOrDefault(NotificationMode.ALL_EVENTS)

    fun setMode(teamId: String, mode: NotificationMode) {
        prefs.edit().putString("mode_$teamId", mode.name).apply()
    }
}
