package com.livescorepuy.app.data

import com.livescorepuy.app.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class SportmonksProvider(
    private val api: SportmonksApi
) : FootballProvider {

    override fun liveMatches(): Flow<Result<List<Match>>> = flow {
        while (true) {
            emit(runCatching {
                api.inPlay().data.mapNotNull(::mapFixture)
            })
            // Sportmonks documents short-interval polling for live scores.
            delay(5_000)
        }
    }

    override suspend fun fixtures(dateIso: String): Result<List<Match>> =
        runCatching { api.fixturesByDate(dateIso).data.mapNotNull(::mapFixture) }

    override suspend fun fixture(id: Long): Result<Match?> =
        runCatching { api.fixture(id).data.firstOrNull()?.let(::mapFixture) }

    private fun mapFixture(f: SportmonksFixture): Match? {
        val home = f.participants.firstOrNull { it.meta?.location == "home" }
            ?: f.participants.firstOrNull() ?: return null
        val away = f.participants.firstOrNull { it.meta?.location == "away" }
            ?: f.participants.getOrNull(1) ?: return null

        val homeScore = f.scores.firstOrNull { it.participant_id == home.id }?.goals ?: 0
        val awayScore = f.scores.firstOrNull { it.participant_id == away.id }?.goals ?: 0
        val state = (f.state?.short_name ?: f.state?.name ?: "").uppercase()

        val status = when {
            state.contains("POST") || state.contains("CANCEL") -> MatchStatus.POSTPONED
            state in setOf("NS", "TBD", "SCHEDULED") -> MatchStatus.UPCOMING
            state.contains("FT") || state.contains("FINISHED") -> MatchStatus.FINISHED
            else -> MatchStatus.LIVE
        }

        val events = f.events.map {
            val type = (it.type?.code ?: it.type?.name ?: "").lowercase()
            val eventType = when {
                "goal" in type -> MatchEventType.GOAL
                "yellow" in type -> MatchEventType.YELLOW
                "red" in type -> MatchEventType.RED
                else -> MatchEventType.KICKOFF
            }
            MatchEvent(
                minute = it.minute ?: 0,
                type = eventType,
                team = if (it.participant_id == home.id) home.name else away.name,
                text = it.result ?: it.type?.name ?: "Event"
            )
        }

        return Match(
            id = f.id.toString(),
            competition = "Provider",
            home = Team(home.id.toString(), home.name, home.name.take(4).uppercase(), "Provider"),
            away = Team(away.id.toString(), away.name, away.name.take(4).uppercase(), "Provider"),
            kickoff = f.starting_at ?: "--:--",
            status = status,
            homeScore = homeScore,
            awayScore = awayScore,
            events = events
        )
    }
}
