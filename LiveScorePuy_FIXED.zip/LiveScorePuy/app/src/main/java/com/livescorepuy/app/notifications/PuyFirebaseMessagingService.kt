package com.livescorepuy.app.notifications

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.livescorepuy.app.MainActivity
import com.livescorepuy.app.R

class PuyFirebaseMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        getSharedPreferences("fcm", MODE_PRIVATE)
            .edit().putString("token", token).apply()
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val manager = getSystemService(NotificationManager::class.java)
        val matchId = message.data["match_id"]
        val eventId = message.data["event_id"] ?: System.currentTimeMillis().toString()

        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra("match_id", matchId)
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            this, eventId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, NotificationBootstrap.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_logo)
            .setContentTitle(message.notification?.title ?: "LiveScore Puy")
            .setContentText(message.notification?.body ?: "Ada pembaruan pertandingan.")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pending)
            .build()

        manager.notify(eventId.hashCode(), notification)
    }
}
