package com.livescorepuy.app.data

import kotlinx.serialization.Serializable
import retrofit2.http.*

@Serializable
data class DeviceRegistration(val token: String, val team_ids: List<String>)

interface BackendApi {
    @GET("v1/live") suspend fun live(): String
    @GET("v1/fixtures") suspend fun fixtures(@Query("date") date: String): String
    @POST("v1/devices/register") suspend fun register(@Body body: DeviceRegistration): String
}
