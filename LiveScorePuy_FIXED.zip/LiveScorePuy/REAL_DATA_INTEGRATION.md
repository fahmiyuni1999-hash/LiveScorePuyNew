# LiveScore Puy — Real Data + FCM

Arsitektur:
`Sportmonks -> LiveScore Puy Backend -> Android / FCM`

Provider token tidak ditanamkan di APK. Backend melakukan polling in-play dan mengirim FCM hanya ke perangkat yang mengikuti tim terkait.

## Backend
Folder `backend/`.

Set:
- SPORTMONKS_TOKEN
- GOOGLE_APPLICATION_CREDENTIALS
- POLL_SECONDS=5

## Android
Tambahkan Firebase project, daftarkan package `com.livescorepuy.app`, lalu letakkan `google-services.json` di `app/`.
Set URL backend melalui `gradle.properties`:
`LIVESCOREPuy_BACKEND_URL=https://domain-backend-anda/`

## Event notifikasi
GOAL, VAR, YELLOW, RED, HALF_TIME, FULL_TIME, KICKOFF, POSTPONED.

Latensi aktual bergantung provider, jaringan, server, dan FCM; interval 5 detik adalah target polling backend, bukan jaminan nol keterlambatan.

## Catatan
Paket ini adalah source lengkap yang disiapkan untuk tahap integrasi credential. Build APK belum diklaim berhasil karena environment ini tidak menyediakan Gradle Wrapper dan Android SDK platform yang lengkap.
